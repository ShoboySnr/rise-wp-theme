<?php
$how_to_use_rise_dashboard = get_field('how_to_the_rise_dashboard');

$main_css_link = get_template_directory_uri().'/styles/main.css';
?>

<?php

wp_footer();

?>

</body>
</html>
