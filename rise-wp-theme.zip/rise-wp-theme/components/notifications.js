class NotificationModal extends HTMLElement {
	constructor() {
		super();
	}
	connectedCallback() {
		this.innerHTML =
			`
	<div class="modal right fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2"
			id="notification-modal">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close-notification-modal" data-dismiss="modal" aria-label="Close"><span
							aria-hidden="true">
							<svg width="24" height="24" viewBox="0 0 24 24" fill="none"
								xmlns="http://www.w3.org/2000/svg">
								<path
									d="M17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41L17.59 5Z"
									fill="#FF671F" />
							</svg>
						</span></button>
						<h4 class="modal-title" id="myModalLabel2">Notifications</h4>
					</div>
				<div class="modal-body">
				<notification-item></notification-item>	
				</div>
			</div>
		</div>
	</div>
`
	}
}
window.customElements.define('notification-modal', NotificationModal);



