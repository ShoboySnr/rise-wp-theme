<svg class="ml-4 group-hover:ml-10" width="20" height="8" viewBox="0 0 20 8" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <path class="group-hover:fill-current text-black"
          d="M16.5 7.5L20 4L16.5 0.5L15.793 1.207L18.086 3.5H0V4.5H18.086L15.793 6.793L16.5 7.5Z"
          fill="#DB3B0F" />
</svg>
