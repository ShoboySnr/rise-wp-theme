<!--
Template Name: Home Template
-->
<?php
if (!defined('ABSPATH')) exit;

get_header();

?>

<?php

get_template_part('template-parts/content','home');

?>


<?php

get_footer();
