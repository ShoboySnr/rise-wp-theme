<svg width="56" height="56" viewBox="0 0 56 56" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <circle cx="28" cy="28" r="27" stroke="#DB3B0F" stroke-width="2" />
    <path
        d="M24.4652 36.4851L32.9502 28.0001L24.4652 19.5151L23.0502 20.9291L30.1222 28.0001L23.0502 35.0711L24.4652 36.4851Z"
        fill="#DB3B0F" />
</svg>
