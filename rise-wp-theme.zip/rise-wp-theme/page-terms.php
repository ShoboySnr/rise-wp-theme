<?php
/*
Template Name: Terms Template
*/

get_header();

?>

<?php

get_template_part('template-parts/content','terms');

?>


<?php

get_footer();

?>

