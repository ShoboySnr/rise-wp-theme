

<footer-prefix href="<?php echo $home_contents['footer_pre_link']['url']?>" image="<?= $home_contents['footer_prefix_image']['url'];?>" alt="<?= $home_contents['footer_prefix_image']['alt'];?>" link-title="<?= $home_contents['footer_pre_link']['title']?>" text="<?= $home_contents['footer_prefix']; ?>"
               color="pink" link-title="<?= $home_contents['footer_pre_link']['title']?>" card-color="#FAB000" color="black" text-color="black" ></footer-prefix>






