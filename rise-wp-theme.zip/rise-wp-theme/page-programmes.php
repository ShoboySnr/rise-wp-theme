<?php
/*
Template Name: Programmes Template
*/

get_header();

?>

<?php

get_template_part('template-parts/content','programmes');

?>


<?php

get_footer();

?>
