<svg class="mr-3 dark:filter dark:grayscale flex-shrink-0" focusable="true" width="25" height="25" viewBox="0 0 25 25" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <circle cx="12.2212" cy="12.8318" r="11.9458" fill="#DAFFE2" />
    <path d="M7.62646 13.199L11.0724 16.5071L16.8155 10.9937" stroke="#4FC068" stroke-width="1.83781"
          stroke-linecap="round" stroke-linejoin="round" />
</svg>