<?php
/*
 * Template Name: Join Template
 *
 */

get_header();

?>

<?php

get_template_part('template-parts/content','join');


?>
<?php
get_footer();
?>
