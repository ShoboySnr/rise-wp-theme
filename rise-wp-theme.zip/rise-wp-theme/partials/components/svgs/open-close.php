<svg class="plus" width="24" height="25" viewBox="0 0 24 25" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <rect x="11" width="3" height="25" fill="#DB3B0F" />
    <rect x="24" y="11" width="3" height="24" transform="rotate(90 24 11)" fill="#DB3B0F" />
</svg>
<svg class="minus" width="24" height="3" viewBox="0 0 24 3" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <rect x="24" width="3" height="24" transform="rotate(90 24 0)" fill="#DB3B0F" />
</svg>


