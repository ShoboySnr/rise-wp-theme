<?php
/*
Template Name: Privacy Template
*/

get_header();

?>

<?php

get_template_part('template-parts/content','privacy');

?>


<?php

get_footer();

?>
