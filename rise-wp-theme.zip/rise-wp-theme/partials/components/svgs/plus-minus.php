<svg class="block" width="28" height="28" viewBox="0 0 28 28" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <rect x="12.4923" width="3.44615" height="28" fill="#DB3B0F" />
    <rect y="15.9385" width="3.44615" height="28" transform="rotate(-90 0 15.9385)"
          fill="#DB3B0F" />
</svg>
<svg class="hidden" width="24" height="3" viewBox="0 0 24 3" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <rect x="24" width="3" height="24" transform="rotate(90 24 0)" fill="#DB3B0F" />
</svg>
