<?php
/*
Template Name: Events Template
*/

get_header();

?>

<?php

get_template_part('template-parts/content','events');

?>

<?php

get_footer();

?>
