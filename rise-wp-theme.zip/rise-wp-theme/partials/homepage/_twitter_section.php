<section class="bg-off-white dark:bg-black400 dark:text-white posts relative">
    <?php
    echo do_shortcode('[twitter_card]');
    ?>
</section>
