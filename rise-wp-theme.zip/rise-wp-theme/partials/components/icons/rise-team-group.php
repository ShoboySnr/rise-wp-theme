<img class="rounded-full dashboard-team-img-2 object-cover inline-block"
     src="<?= get_template_directory_uri().'/assets/images/image2.jpeg'; ?>" title="<?= __('Rise Team', 'rise-wp-theme') ?>" alt="<?= __('Rise Team', 'rise-wp-theme') ?>">
<img class="rounded-full dashboard-team-img object-cover inline-block relative"
     src="<?= get_template_directory_uri().'/assets/images/image1.jpg'; ?>" title="<?= __('Rise Team', 'rise-wp-theme') ?>" alt="<?= __('Rise Team', 'rise-wp-theme') ?>">
<img class="rounded-full dashboard-team-img-2 object-cover inline-block"
     src="<?= get_template_directory_uri().'/assets/images/image3.jpg'; ?>" title="<?= __('Rise Team', 'rise-wp-theme') ?>" alt="<?= __('Rise Team', 'rise-wp-theme') ?>">
