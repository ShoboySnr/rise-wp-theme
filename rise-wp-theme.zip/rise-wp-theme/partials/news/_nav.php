<div class="hidden sm:block">
  <button data-carousel="news-items" aria-label="slide left" type="button" class="mr-4 news-left opacity-30">
        <?php include RISE_THEME_SVG_COMPONENTS.'/left-arrow-circle-colored.php' ?>
    </button>
  <button data-carousel="news-items" aria-label="slide right" type="button" class="news-right">
        <?php include RISE_THEME_SVG_COMPONENTS.'/right-arrow-circle-colored.php' ?>
    </button>
</div>
