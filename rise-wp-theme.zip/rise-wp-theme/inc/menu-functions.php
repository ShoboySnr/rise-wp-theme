<?php

function rise_wp_add_additional_menu_to_primary_menu() {

}
