<div class="side_image bg-gray400 top-0"></div>
