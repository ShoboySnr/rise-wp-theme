<svg class="ml-2 items-center" width="9" height="16" viewBox="0 0 9 16" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <path d="M1 1L8 8L1 15" stroke="#F15400" stroke-width="1.5" stroke-linecap="round"
          stroke-linejoin="round" />
</svg>
