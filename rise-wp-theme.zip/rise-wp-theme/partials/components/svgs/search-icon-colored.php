<svg class="absolute left-8  top-1/2 transform -translate-y-1/2" width="14" height="15"
     viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="6.6618" cy="6.84442" rx="5.51373" ry="5.99237" stroke="#F15400"
             stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M10.4967 11.3232L12.6584 13.6665" stroke="#F15400" stroke-width="1.5"
          stroke-linecap="round" stroke-linejoin="round" />
</svg>
