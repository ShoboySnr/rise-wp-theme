<svg class="fill-current text-black dark:text-white" width="20" height="7" viewBox="0 0 20 7" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <path
        class="fill-current text-white group-hover:text-black dark:group-hover:text-black"
        d="M16.5 6.99976L20 3.49976L16.5 -0.000244141L15.793 0.706756L18.086 2.99976H0V3.99976H18.086L15.793 6.29276L16.5 6.99976Z"
        fill="white" />
</svg>
