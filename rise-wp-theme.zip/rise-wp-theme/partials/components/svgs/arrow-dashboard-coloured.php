<svg focusable="false" class="ml-5 fill-current group-hover:text-red" width="20" height="8" viewBox="0 0 20 8" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.5 7.5L20 4L16.5 0.5L15.793 1.207L18.086 3.5H0V4.5H18.086L15.793 6.793L16.5 7.5Z"
          fill="#0D0D0D" />
</svg>
