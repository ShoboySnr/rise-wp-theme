<svg focusable="false" class="mr-3" width="17" height="15" viewBox="0 0 17 15" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <path d="M0.75 7.27441L15.75 7.27441" stroke="#DB3B0F" stroke-width="1.5"
          stroke-linecap="round" stroke-linejoin="round" />
    <path d="M6.7998 13.2988L0.749804 7.27476L6.7998 1.24976" stroke="#DB3B0F"
          stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>