<?php
/*
Template Name: Accessibility Template
*/

get_header();

?>

<?php

get_template_part('template-parts/content','accessibility');

?>


<?php

get_footer();

?>

