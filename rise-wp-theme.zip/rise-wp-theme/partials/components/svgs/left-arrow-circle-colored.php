<svg width="56" height="56" viewBox="0 0 56 56" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <g opacity="1">
        <circle cx="28" cy="28" r="27" stroke="#FA0D05" stroke-width="2" />
        <path
            d="M31.5348 19.5149L23.0498 27.9999L31.5348 36.4849L32.9498 35.0709L25.8778 27.9999L32.9498 20.9289L31.5348 19.5149Z"
            fill="#FA0D05" />
    </g>
</svg>
